package com.demo.dao;

import java.util.List;

import com.demo.bean.Product;

public interface ProductDao {

	

	void addProduct(Product p);

	Product searchByid(int id);

	//List<Product> displayAll();
	void  displayAll();

	void delete(int id1);

	

	

	Product modifyByid(int id4, String name4, int qty4);

	Product displayByid(int id2);

	//Product modifyByid(int id1, String name1, int qty1);

}
