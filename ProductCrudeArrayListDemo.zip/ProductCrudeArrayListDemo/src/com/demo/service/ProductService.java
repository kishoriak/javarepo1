package com.demo.service;

//import java.util.List;

import com.demo.bean.Product;

public interface ProductService {

	 void addProduct();

	Product searchByid(int id);

	//List<Product> displayAll();
	void displayAll();

	void deleteProduct(int id1);

	Product modifyByid(int id4, String name4, int qty4);

	Product displayByid(int id2);

	

	
}
