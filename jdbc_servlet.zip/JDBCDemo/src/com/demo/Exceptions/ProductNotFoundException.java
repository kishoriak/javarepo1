package com.demo.Exceptions;

public class ProductNotFoundException extends Exception {
   public ProductNotFoundException(String msg) {
	   super(msg);
   }
}
