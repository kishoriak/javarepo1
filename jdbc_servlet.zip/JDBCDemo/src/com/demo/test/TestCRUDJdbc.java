package com.demo.test;

import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.demo.Exceptions.ProductNotFoundException;
import com.demo.bean.Product;
import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;

public class TestCRUDJdbc {
	public static void main(String[] args) {
	int choice=0;
	Scanner sc=new Scanner(System.in);
	//service class object to call methods of service layer
	ProductService productService=new ProductServiceImpl();
	do {
	System.out.println("1. add new Product\n 2. Delete Product \n3. update product");
	System.out.println("4. search by by id\n 5. Display all\n 7. Exit");
	System.out.println("choice: ");
	choice=sc.nextInt();
	//switcase for all option
	switch(choice) {
	case 1:
		productService.addProduct();
		break;
	case 2:
		System.out.println("Enter id");
		int id=sc.nextInt();
		boolean flag=productService.deleteProduct(id);
		if (flag) {
			System.out.println("deletion done");
		}
		else {
			System.out.println("Product not found");
		}
		
		break;
	case 3:
		System.out.println("Enter id");
		 id=sc.nextInt();
		System.out.println("Enter price");
		double pr=sc.nextDouble();
		System.out.println("Enter qty");
		int qty=sc.nextInt();
		flag=productService.updateProduct(id,pr,qty);
		if(flag) {
			System.out.println("updation done");
		}
		else {
			System.out.println("updation not done");
		}
		
		break;
	case 4:
		System.out.println("Enter id");
		 id=sc.nextInt();
		Product p=null;
		try {
			p = productService.SearchById(id);
		} catch (ProductNotFoundException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		if(p!=null) {
			System.out.println(p);
		}
		else {
			System.out.println("not found");
		}
		
		
		break;
	case 5:
		List<Product> plist=productService.getAllProduct();			
		for(Product per:plist) {
			System.out.println(per);
		}
		//elist.forEach(e1->{System.out.println(e1);});  //consumer
		//elist.forEach(System.out::println);
		break;
	case 7:
		sc.close();
		productService.closeConnection();
		System.exit(0);
		break;
	}
	}while(choice!=7);
}

}
