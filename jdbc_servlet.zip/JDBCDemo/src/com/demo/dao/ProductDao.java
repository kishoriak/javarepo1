package com.demo.dao;

import java.util.List;

import com.demo.Exceptions.ProductNotFoundException;
import com.demo.bean.Product;

public interface ProductDao {

	int addProduct(Product p);

	void closeConnection();

	List<Product> getAllProduct();

	Product searchProductById(int id) throws ProductNotFoundException;

	boolean deleteProduct(int id);

	boolean updateProduct(int id, double pr, int qty);

}
