package com.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//singleton pattern
public class DBUtil {
	static Connection conn=null;
	/*public static Connection getMyConnection() {
		if(conn==null) {
			String url = "jdbc:derby:c:\\mydata\\hsbcdb";
	        String user = "hsbc";
	        String password = "hsbc123";
	        try {
				conn = DriverManager.getConnection(url, user, password);
				if (conn != null) {
		            System.out.println("Connected to database ");
		        }
			} catch (SQLException e) {
				System.out.println("Connection not done ");
				e.printStackTrace();
			}
			
		}
		return conn;
	}*/
	
	public static Connection getMyConnection() {
		if(conn==null) {
			try {
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				String url="jdbc:mysql://localhost:3306/test";
				conn=DriverManager.getConnection(url,"root","root123");
				if (conn != null) {
		            System.out.println("Connected to database ");
		        }
			}catch(SQLException e) {
				System.out.println("Connection not done ");
				e.printStackTrace();
			}
		}
		return conn;
	}
	
	
	
	
	public static void closeMyConnection() {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
