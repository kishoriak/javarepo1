package com.demo.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demo.Exceptions.ProductNotFoundException;
import com.demo.bean.Product;

public class ProductDaoImpl implements ProductDao{
	static Connection conn;
	static PreparedStatement psins,pssel,psbyId,psdel,psupdate;
	static {
		conn=DBUtil.getMyConnection();
		try {
			 psins=conn.prepareStatement("insert into product_hsbc values(?,?,?,?,?)");
			 pssel=conn.prepareStatement("select * from product_hsbc");
			 psbyId=conn.prepareStatement("select * from product_hsbc where pid=?");
			 psdel=conn.prepareStatement("delete from product_hsbc where pid=?");
			 psupdate=conn.prepareStatement("update product_hsbc set price=?,qty=? where pid=?");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public int addProduct(Product p) {
		        
		        try {
		        	psins.setInt(1,p.getPid());
					psins.setString(2, p.getPname());
					psins.setString(3, p.getPdesc());
			        psins.setDouble(4, p.getPrice());
			        psins.setInt(5, p.getQty());
					return psins.executeUpdate();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					
					e1.printStackTrace();
					return 0;
				}
		        
	}

	@Override
	public void closeConnection() {
		DBUtil.closeMyConnection();
		
	}

	@Override
	public List<Product> getAllProduct() {
		List<Product> plist=new ArrayList<>();
		try {
			ResultSet rs=pssel.executeQuery();
			while(rs.next()) {
				Product e=new Product(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDouble(4),rs.getInt(5));
				plist.add(e);
			}
			return plist;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Product searchProductById(int id) throws ProductNotFoundException {
		try {
			psbyId.setInt(1,id);
			ResultSet rs=psbyId.executeQuery();
			if(rs.next()) {
				Product p=new Product(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDouble(4),rs.getInt(5));
				return p;
			}
			else {
				throw new ProductNotFoundException("Product not found");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public boolean deleteProduct(int id) {
		try {
			psdel.setInt(1,id);
			int n=psdel.executeUpdate();
			if(n>0)
				return true;
			else 
				return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean updateProduct(int id, double pr, int qty) {
		try {
			psupdate.setDouble(1,pr);
			psupdate.setInt(2, qty);
			psupdate.setInt(3, id);
			int n=psupdate.executeUpdate();
			if(n>0)
				return true;
			else
				return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		
	}

}
