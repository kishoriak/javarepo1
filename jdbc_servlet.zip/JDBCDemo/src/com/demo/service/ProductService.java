package com.demo.service;

import java.util.List;
import java.util.Set;

import com.demo.Exceptions.ProductNotFoundException;
import com.demo.bean.Product;


public interface ProductService {

	void addProduct();

	Product SearchById(int id) throws ProductNotFoundException;

	boolean deleteProduct(int id);

	void closeConnection();

	List<Product> getAllProduct();

	boolean updateProduct(int id, double pr, int qty);



}
