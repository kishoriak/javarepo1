package com.demo.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.demo.Exceptions.ProductNotFoundException;
import com.demo.bean.Product;

import com.demo.dao.ProductDao;
import com.demo.dao.ProductDaoImpl;


public class ProductServiceImpl implements ProductService{
      private ProductDao productDao;
      static Scanner sc;
      static {
    	  sc=new Scanner(System.in);
      }
      
	public ProductServiceImpl() {
		this.productDao=new ProductDaoImpl();
	}

	@Override
	public void addProduct() {
		System.out.println("enter Id");
		int id=sc.nextInt();
		System.out.println("enter Name");
		sc.nextLine();
		String nm=sc.nextLine();
		System.out.println("enter desc");
		String des=sc.nextLine();
		System.out.println("enter price");
		double price=sc.nextDouble();
		System.out.println("enter qty");
		int qty=sc.nextInt();
		Product p=new Product(id,nm,des,price,qty);
		int n=productDao.addProduct(p);
	}

	@Override
	public Product SearchById(int id) throws ProductNotFoundException {
		return productDao.searchProductById(id);
	}

	@Override
	public List<Product> getAllProduct() {
		return productDao.getAllProduct();
	}

	@Override
	public boolean deleteProduct(int id) {
		return productDao.deleteProduct(id);
	}
    public void closeConnection() {
    	productDao.closeConnection();
    }

	@Override
	public boolean updateProduct(int id, double pr, int qty) {
		return productDao.updateProduct(id,pr,qty);
	}  
}
