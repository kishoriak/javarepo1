package com.demo.exceptions;

public class LessAmountException extends Exception{
	public LessAmountException(String msg) {
		super(msg);
	}
}
