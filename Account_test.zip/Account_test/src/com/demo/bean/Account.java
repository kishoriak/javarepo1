package com.demo.bean;

public class Account {
	int iD=0;
	String Name=null;
	double balance=0.0;
	
	static int account_id=0;
	
	public Account() {
		super();
		this.iD=account_id;
		account_id++;
		Name="default";
		balance=2000.0;
	}
	
	public Account(String Name) {
		super();
		this.iD=account_id;
		account_id++;
		this.Name=Name;
		balance=2000.0;
	}
	
	public Account(String Name,int id,Double Balance) {
		super();
		this.iD=id;
		this.Name=Name;
		balance=Balance;
	}
	
	public boolean WithDraw(double amt) {
		return true;
	}

	public int getiD() {
		return iD;
	}

	public void setiD(int iD) {
		this.iD = iD;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public static int getAccount_id() {
		return account_id;
	}

	public static void setAccount_id(int account_id) {
		Account.account_id = account_id;
	}

	@Override
	public boolean equals(Object obj) {
		if (iD != ((Account)obj).iD) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "Account [iD=" + iD + ", Name=" + Name + ", balance=" + balance + "]";
	}
	
	
}
