package com.demo.test;

import java.util.List;
import java.util.Scanner;

import com.demo.bean.Account;
import com.demo.service.AccountService;
import com.demo.service.AccountServiceImpl;

public class AccountTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int choice=0;
		AccountService accountService=new AccountServiceImpl();
		do {
			System.out.println("1.Add\n2.Withdraw\n3.Search\n4.Display All\n5.Close Account\n6.Display by Id\n7.Deposit\n8.Exit");
			System.out.println("Enter Choice");
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				accountService.addAccount();
				break;
			case 2:
				break;
			case 3:
				System.out.println("Enter the id");
				int id=0;
				id=sc.nextInt();
				Account a1=accountService.find(id);
				if(a1==null) {
					System.out.println("Account Not Found");
				}
				else {
					System.out.println(a1);
				}
				break;
			case 4:
				List<Account> alist =accountService.displayAll();
				for(Account a2:alist) {
					System.out.println(a2);
				}
				break;
			case 5:
				System.out.println("Enter the id");
				int id1=0;
				id1=sc.nextInt();
				Account a =accountService.find(id1);
				if(a!=null) {
					accountService.removeAccount(a);
				}
				break;
			case 6:
				System.out.println("Enter the id");
				int id2=0;
				id=sc.nextInt();
				Account a2=accountService.find(id);
				if(a2==null) {
					System.out.println("Account Not Found");
				}
				else {
					System.out.println(a2);
				}
				break;
			case 7:
				accountService.deposit();
				break;				
			case 8:
				System.exit(0);
				break;
			}
		}while(choice!=8);
	}

}
