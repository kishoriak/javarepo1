package com.demo.dao;

import java.util.ArrayList;
import java.util.List;

import com.demo.bean.Account;

public class AccountDaoImpl implements AccountDao {
	
	static List<Account> alist;
	static {
		alist=new ArrayList<>();
	}
	public void addAccount(Account a) {
		alist.add(a);
		for(Account a1:alist) {
			System.out.println(a1);
		}
	}
	
	public List<Account> getAllAccounts(){
		return alist;
	}

	@Override
	public Account findAccount(int id) {
		// TODO Auto-generated method stub
		int pos=alist.indexOf(new Account(null,id,0.0));
		return alist.get(pos);
	}

	@Override
	public void removeAccount(Account a) {
		// TODO Auto-generated method stub
		List<Account> templist=new ArrayList<>();
		for(Account a1:alist) {
			if(a1.equals(a)) {
				continue;
			}
			templist.add(a1);
		}
		alist=templist;
	}

	@Override
	public void depositAccount(int iD,double amt) {
		// TODO Auto-generated method stub
		for(Account a1:alist) {
			if(a1.getiD()==iD) {
				a1.setBalance(a1.getBalance()+amt);
				System.out.println("Succesfully Deposited");
				return;
			}
		}
		System.out.println("Account not Found");
	}
}
