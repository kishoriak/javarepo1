package com.demo.dao;

import java.util.List;

import com.demo.bean.Account;

public interface AccountDao {

	List<Account> getAllAccounts();

	void addAccount(Account a);

	Account findAccount(int id);

	void removeAccount(Account a);

	void depositAccount(int iD,double amt);
}
