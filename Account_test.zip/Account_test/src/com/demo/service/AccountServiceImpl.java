package com.demo.service;

import java.util.List;
import java.util.Scanner;

import com.demo.bean.Account;
import com.demo.dao.AccountDao;
import com.demo.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {
	private AccountDao accountDao;
	
	public AccountServiceImpl() {
		accountDao =new AccountDaoImpl();
	}


	@Override
	public void addAccount() {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name ");
		String name=null;
		name=sc.nextLine();
		Account a=new Account(name);
		accountDao.addAccount(a);
	}
	
	@Override
	public void deposit() {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the id ");
		int iD=0;
		iD=sc.nextInt();
		System.out.println("Enter the amt");
		double amt=0.0;
		amt=sc.nextDouble();
		accountDao.depositAccount(iD,amt);
	}


	public List<Account> displayAll() {
		return accountDao.getAllAccounts();
	}


	@Override
	public Account find(int id) {
		// TODO Auto-generated method stub
		return accountDao.findAccount(id);
	}


	@Override
	public void removeAccount(Account a) {
		// TODO Auto-generated method stub
		accountDao.removeAccount(a);
	}

}
