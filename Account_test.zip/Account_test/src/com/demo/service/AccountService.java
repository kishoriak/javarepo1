package com.demo.service;

import java.util.List;

import com.demo.bean.Account;

public interface AccountService {
	
	void deposit();

	void addAccount();

	List<Account> displayAll();

	Account find(int id);

	void removeAccount(Account a);
	
	
}
