package com.training.service;

import java.util.List;
import java.util.Scanner;

import com.training.bean.Product;
import com.training.dao.ProductDao;
import com.training.dao.ProductDaoImpl;

public class ProductServiceImpl implements ProductService{
	private ProductDao productDao;

	public ProductServiceImpl() {
		productDao = new ProductDaoImpl();
	}

	@Override
	public void addProduct() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Id");
		int id = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Name: ");
		String name = sc.nextLine();
		System.out.println("Enter Qty: ");
		int qty = sc.nextInt();
		Product p = new Product(id, name, qty);
		productDao.addProduct(p);
		
	}

	@Override
	public List<Product> displayAll() {
		return productDao.getAllProducts();
		
	}

	@Override
	public Product searchProduct(int id) {
		// TODO Auto-generated method stub
		return productDao.searchById(id);
	}

	@Override
	public Product displayById(int id) {
		return productDao.searchById(id);
	}

	@Override
	public boolean delete(int id) {
		return productDao.delete(id);
	}

	@Override
	public boolean modifyQty(int id, int qty) {
		// TODO Auto-generated method stub
		return productDao.modifyQty(id, qty);
	}

	
	
}
