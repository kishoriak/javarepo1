package com.training.service;

import java.util.List;

import com.training.bean.Product;

public interface ProductService {

	void addProduct();

	List<Product> displayAll();

	Product searchProduct(int id);

	Product displayById(int id);

	boolean delete(int id);

	boolean modifyQty(int id, int qty);

}
