package com.training.dao;

import java.util.ArrayList;
import java.util.List;

import com.training.bean.Product;

public class ProductDaoImpl implements ProductDao{
	
	static List<Product> plist;
	static{
		plist = new ArrayList<>();
		plist.add(new Product(12,"chair",2000));
		plist.add(new Product(13,"table",2000));
	}
	
	@Override
	public void addProduct(Product p) {
		plist.add(p);
		
	}

	@Override
	public List<Product> getAllProducts() {
		
		return plist;
	}

	@Override
	public Product searchById(int id) {
		int pos = plist.indexOf(new Product(id, null,0));
		if(pos!=-1) {
			return plist.get(pos);
		}
		return null;
	}

	@Override
	public boolean delete(int id) {
		Product p = searchById(id);
		return plist.remove(p);
	}

	@Override
	public boolean modifyQty(int id, int qty) {
		Product p = searchById(id);
		if(p!=null) {
			p.setQty(qty);
			return true;
		}
		return false;
	}

}
