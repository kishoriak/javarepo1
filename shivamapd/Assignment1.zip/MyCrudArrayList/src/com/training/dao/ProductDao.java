package com.training.dao;

import java.util.List;

import com.training.bean.Product;

public interface ProductDao {

	void addProduct(Product p);

	//List<Product> getAllProducts();

	Product searchById(int id);

	List<Product> getAllProducts();

	boolean delete(int id);

	boolean modifyQty(int id, int qty);

}
