package com.demo.notes;

public class TextAndImageNote extends TextNote{
	private String url;
	//default constructor
	public TextAndImageNote() {
		super();
	}
	// parameterized constructor
	public TextAndImageNote(String text, String url) {
		super(text);
		this.url = url;
	}
	//getter and setter methods
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	@Override
	public String toString() {
		return "Text and Image Note: " + getText() + ", " + url;
	}
	
	
}
