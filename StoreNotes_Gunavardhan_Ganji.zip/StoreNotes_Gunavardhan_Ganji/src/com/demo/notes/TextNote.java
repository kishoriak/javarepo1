package com.demo.notes;

public class TextNote {
	private String text;
	
	//default constructor
	public TextNote() {
		super();
	}
	// parameterized constructor
	public TextNote(String text) {
		super();
		this.text = text;
	}

	//getter and setter methods
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return "TextNote: " + text;
	}
	
	
	
}
