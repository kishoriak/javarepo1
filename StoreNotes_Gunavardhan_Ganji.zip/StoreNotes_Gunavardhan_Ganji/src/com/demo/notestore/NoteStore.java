package com.demo.notestore;

import java.util.ArrayList;

import com.demo.notes.TextAndImageNote;
import com.demo.notes.TextNote;

public class NoteStore {
	//creating arraylists for text and textandImage notes
	private static ArrayList<TextNote> notesList;
	private static ArrayList<TextAndImageNote> notesAndImagesList;
	static {
		notesList = new ArrayList<>();
		notesAndImagesList = new ArrayList<>();
	}
	
	//stores the text into list
	public void storeNote(String text) {
		notesList.add(new TextNote(text));		
	}
	//stores the text and url into the list
	public void storeNote(String text, String url) {
		notesAndImagesList.add(new TextAndImageNote(text, url));
	}
	//for displaying all the text notes
	public ArrayList<TextNote> getAllTextNotes(){
		return notesList;
	}
	//for displaying all the text and image notes
	public ArrayList<TextAndImageNote> getAllTextAndImageNotes(){
		return notesAndImagesList;
	}
		
		
}
