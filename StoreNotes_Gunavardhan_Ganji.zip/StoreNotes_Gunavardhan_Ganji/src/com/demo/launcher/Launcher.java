package com.demo.launcher;

import java.util.ArrayList;

import com.demo.notes.TextAndImageNote;
import com.demo.notes.TextNote;
import com.demo.notestore.NoteStore;

public class Launcher {
	static NoteStore note = new NoteStore();
	
	//method for displaying all the text Notes
	public static void displayTextNotes(){
		ArrayList<TextNote> notes = note.getAllTextNotes();
		for(TextNote notee: notes) {
			System.out.println(notee.toString());
		}
	}
	
	//method for displaying all the text and Image Notes
	public static void displayTextAndImageNotes(){
		ArrayList<TextAndImageNote> notes = note.getAllTextAndImageNotes();
		for(TextAndImageNote notee: notes) {
			System.out.println(notee.toString());
		}
	}
	
	public static void main(String[] args) {
		
		String text1 = "Java is a set of computer software and specifications developed by James Gosling at Sun Microsystems";
		String text2 = "Few books to read-Ikigai, How to win friends and influence people";
		//adding 2 text notes
		note.storeNote(text1);
		note.storeNote(text2);
		
		String text3 = "The shopping list is on my fridge";
		String text4 = "The size label of Jack's shirt";
		
		String url1 = "/foo/bar/image1.jpg";
		String url2 = "/foo/bar/image2.jpg";
		
		//adding 2 text and image notes
		note.storeNote(text3, url1);
		note.storeNote(text4, url2);
		
		//displaying all the notes
		displayTextNotes();
		displayTextAndImageNotes();
	}

}
