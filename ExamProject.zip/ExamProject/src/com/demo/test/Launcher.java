package com.demo.test;

import com.demo.service.NoteStore;
import com.demo.service.NoteStoreImplementation;

public class Launcher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NoteStore noteStore=new NoteStoreImplementation();
		
		noteStore.storeNote("Java is a seet of computer software and specifications developed by James Gosling at Sun Microsystems");
		noteStore.storeNote("Few Books to Read- Ikigai, How to win friends and influence people");
		
		noteStore.storeNote("The shopping list on my fridge", "//foo/bar1/bar2/imgset1.jpg");
		noteStore.storeNote("The size label of jack shirt", "//foo/bar1/bar2/imgset2.jpg");
		
		noteStore.displayTextNotes();
		noteStore.displayTextAndImageNote();
	}

}
