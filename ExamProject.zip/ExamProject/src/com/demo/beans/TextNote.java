package com.demo.beans;

public class TextNote {
	
	//create instance variable text
	private String text;

	//getters and setters for text
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	//default constructor
	public TextNote() {
		super();
		// TODO Auto-generated constructor stub
	}

	//parameterized constructor
	public TextNote(String text) {
		super();
		this.text = text;
	}

	//Overriding toString method
	@Override
	public String toString() {
		return "TextNote [text=" + text + "]";
	}
	
	
	
}
