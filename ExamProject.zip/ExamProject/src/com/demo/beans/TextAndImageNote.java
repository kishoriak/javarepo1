package com.demo.beans;

public class TextAndImageNote extends TextNote{
	
	//create instance variable text and url
	private String text;
	private String url;
	
	//getters and setters
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	//parameterized constructor
	public TextAndImageNote(String text, String url) {
		super();
		this.text=text;
		this.url = url;
	}
	
	//default constructor
	public TextAndImageNote() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "TextAndImageNote [text=" + text + ", url=" + url + "]";
	}
	
}
