package com.demo.dao;

import java.util.List;

import com.demo.beans.TextAndImageNote;
import com.demo.beans.TextNote;

public class NoteDaoImplementation implements NoteDao{
	
	static TextNote notes[];
	static int index=0;
	
	static {
		notes=new TextNote[4];
	}

	@Override
	public void storeNote(String text) {
		// TODO Auto-generated method stub
		notes[index]=new TextNote(text);
		index++;
	}

	@Override
	public void storeNote(String text, String url) {
		// TODO Auto-generated method stub
		notes[index]=new TextAndImageNote(text, url);
		index++;
	}

	@Override
	public TextNote[] getAllTextNote() {
		// TODO Auto-generated method stub
		TextNote allTextNotes[]=new TextNote[4];
		
		//this counter keeps the length of allNotes Array
		int j=0;
		for(int i=0; i<notes.length; i++) {
			if((notes[i] instanceof TextNote) && !(notes[i] instanceof TextAndImageNote)) {
				allTextNotes[j]=notes[i];
				j++;
			}
		}
		return allTextNotes;
	}

	@Override
	public TextAndImageNote[] getAllTextAndImageNotes() {
		// TODO Auto-generated method stub
		TextAndImageNote allTextAndImagesNotes[]=new TextAndImageNote[4];
		//this counter keeps the length of allNotes Array
		int j=0;
		for(int i=0; i<notes.length; i++) {
			if(notes[i] instanceof TextAndImageNote) {
				allTextAndImagesNotes[j]=(TextAndImageNote)notes[i];
				j++;
			}
		}
		return allTextAndImagesNotes;
	}

	
	
}
