package com.demo.dao;

import java.util.List;

import com.demo.beans.TextAndImageNote;
import com.demo.beans.TextNote;

public interface NoteDao{

	public void storeNote(String text);
	public void storeNote(String text, String url);
	public TextNote[] getAllTextNote();
	public TextAndImageNote[] getAllTextAndImageNotes();

}
