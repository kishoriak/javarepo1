package com.demo.service;

import java.util.List;

import com.demo.beans.TextNote;
import com.demo.beans.TextAndImageNote;
import com.demo.dao.NoteDao;
import com.demo.dao.NoteDaoImplementation;

public class NoteStoreImplementation implements NoteStore{

	NoteDao noteDao=new NoteDaoImplementation();
	@Override
	public void storeNote(String text) {
		// TODO Auto-generated method stub
		noteDao.storeNote(text);
	}
	

	@Override
	public void displayTextNotes() {
		// TODO Auto-generated method stub
		TextNote array[]=noteDao.getAllTextNote();
		int j=0;
		while(array[j]!=null) {
			System.out.println("Text Note "+(j+1)+": "+((TextNote)array[j]).getText());
			j++;
		}
	}

	@Override
	public void displayTextAndImageNote() {
		// TODO Auto-generated method stub
		TextAndImageNote array[]=noteDao.getAllTextAndImageNotes();
		int j=0;
		while(array[j]!=null) {
			System.out.println("Text and Image Note "+(j+1)+": "+((TextNote)array[j]).getText()+", "+(array[j]).getUrl());
			j++;
		}
	}


	@Override
	public void storeNote(String text, String url) {
		// TODO Auto-generated method stub
		noteDao.storeNote(text, url);
	}

}
