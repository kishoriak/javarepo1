package com.demo.service;

import java.util.List;

import com.demo.beans.TextNote;

public interface NoteStore{
	public void storeNote(String text);
	public void displayTextNotes();
	public void displayTextAndImageNote();
	public void storeNote(String text, String url);
}
