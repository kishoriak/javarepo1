package com.demo.test;

import java.util.List;
import java.util.Scanner;


import com.demo.bean.TextAndImageNote;
import com.demo.bean.TextNote;
import com.demo.service.NoteService;
import com.demo.service.NoteServiceImpl;


public class Launcher {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int choice=0;
		NoteService noteService=new NoteServiceImpl();
		do {
		System.out.println("1.Add TextNote \n2.Add TextAndImageNote\n3.DisplayTextNotes\n4.DisplayTextAndImageNotes\n5.Exit");
		System.out.println("Enter choice:");
		choice=sc.nextInt();
		switch(choice) {
		case 1:
			noteService.addTextNote();
			System.out.println("Adding Done");
			break;
		case 2:
			noteService.addTextAndImageNote();
			System.out.println("Adding Done");
			break;
		case 3:
			List<TextNote> nlist = noteService.displayTextNotes();
			for(TextNote t:nlist) {
				System.out.println(t);
			}
			break;
		case 4:
			List<TextAndImageNote> tlist= noteService.displayTextAndImagesNotes();
			for(TextAndImageNote t1:tlist) {
				System.out.println(t1);
			}
			break;
		case 5:
			sc.close();
			System.exit(0);
			}
		}while(choice!=5);
	}
}
