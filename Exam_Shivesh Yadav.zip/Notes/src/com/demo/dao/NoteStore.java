package com.demo.dao;

import java.util.List;

import com.demo.bean.TextAndImageNote;
import com.demo.bean.TextNote;

public interface NoteStore {

	void storeNote(TextAndImageNote p1);

	void storeNote(TextNote p);

	List<TextAndImageNote> getAllTextAndImageNotes();

	List<TextNote> getAllTextNotes();



}
