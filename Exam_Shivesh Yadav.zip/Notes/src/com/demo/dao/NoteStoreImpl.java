package com.demo.dao;

import java.util.ArrayList;
import java.util.List;

import com.demo.bean.TextAndImageNote;
import com.demo.bean.TextNote;

public class NoteStoreImpl implements NoteStore {

	static List<TextNote> list1;
	static List<TextAndImageNote> list2;
	static {
		list1=new ArrayList<>();
		list2=new ArrayList<>();
		
		//Sample 2 Inputs as asked in the problem statement
		list1.add(new TextNote("Message"));
		list1.add(new TextNote("Message"));
		list2.add(new TextAndImageNote("Message ", " URL"));
		list2.add(new TextAndImageNote("Message", "URL"));
		
		
	}

	@Override
	public void storeNote(TextAndImageNote p1) {
		list2.add(p1);
		
	}

	@Override
	public List<TextNote> getAllTextNotes() {
		return list1;
	}

	@Override
	public void storeNote(TextNote p) {
		list1.add(p);
		
	}

	@Override
	public List<TextAndImageNote> getAllTextAndImageNotes() {
		return list2;
	}

}
