package com.demo.service;

import java.util.List;
import java.util.Scanner;

import com.demo.bean.TextAndImageNote;
import com.demo.bean.TextNote;
import com.demo.dao.NoteStore;
import com.demo.dao.NoteStoreImpl;

public class NoteServiceImpl implements NoteService{
	
	 
	  private NoteStore NoteStore;
	  
	  public NoteServiceImpl() { 
	  NoteStore=new NoteStoreImpl();
	  }
	  

	@Override
	public void addTextNote() {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter text");
		String txt=sc.next();
		TextNote p=new TextNote(txt);
		NoteStore.storeNote(p);
	}

	@Override
	public void addTextAndImageNote() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter text");
		String txt1=sc.next();
		System.out.println("Enter image url");
		String img=sc.next();
		TextAndImageNote p1=new TextAndImageNote(txt1,img);
		NoteStore.storeNote(p1);
		
	}

	@Override
	public List<TextNote> displayTextNotes() {
		return NoteStore.getAllTextNotes();
		
	}

	@Override
	public List<TextAndImageNote> displayTextAndImagesNotes() {
		return NoteStore.getAllTextAndImageNotes();
		
	}

}
