package com.bank.bean;

public class SavingsAcc extends Account{
	private String chqbk;
	private static final double  inr;
	private static final double minbal;
	
	static {
		inr=0.04;
		minbal=2500;
	}
	
	public SavingsAcc() {
		super();
	}

	public SavingsAcc(int id, String name, double bal,String chqbk) {
		super();
		this.chqbk = chqbk;
	}

	public String getChqbk() {
		return chqbk;
	}

	public void setChqbk(String chqbk) {
		this.chqbk = chqbk;
	}

	public static double getInr() {
		return inr;
	}

	public static double getMinbal() {
		return minbal;
	}
	
	@Override
	public String toString() {
		return super.toString()+"SavingsAcc [chqbk=" + chqbk + "]";
	}

}