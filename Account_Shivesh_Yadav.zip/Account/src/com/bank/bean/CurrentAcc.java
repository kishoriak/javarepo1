package com.bank.bean;

public class CurrentAcc extends Account{
	private static final  double minbal;
	private static  final double inr;
	private int trnsc=0;
	static{
		minbal=0.0;
		inr=0.06;
		
	}
	public CurrentAcc(int id, String name, double bal) {
		super();
	}
	
	public void settransc() {
		trnsc++;
	}
	@Override
	public String toString() {
		return super.toString()+"No.of Transactions is:"+trnsc;
	}
	
}