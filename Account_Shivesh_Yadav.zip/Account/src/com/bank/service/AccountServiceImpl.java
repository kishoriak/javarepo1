package com.bank.service;
import java.util.List;
import java.util.Scanner;

import com.bank.bean.Account;
import com.bank.bean.CurrentAcc;
import com.bank.bean.SavingsAcc;
import com.bank.dao.AccountDao;
import com.bank.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {
	private AccountDao accountDao;
	private CurrentAcc ac;
	
	public AccountServiceImpl() {
		accountDao=new AccountDaoImpl();
	}
	
	Scanner sc=new Scanner (System.in);
	
	@Override
	public void createSAcc() {
		System.out.println("Enter Id:");
		int id=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Name:");
		String name=sc.nextLine();
		System.out.println("Enter Chequebook no:");
		String chqbk=sc.nextLine();
		System.out.println("Deposit atleast 2500 for opening a savings account.");
		System.out.println("Enter the ammount to be deposited:");
		double bal=sc.nextDouble();
		Account as=new SavingsAcc(id,name,bal,chqbk);
		accountDao.createSAcc(as);
		
	}


	@Override
	public void createCAcc() {
		System.out.println("Enter Id:");
		int id=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Name:");
		String name=sc.nextLine();
		System.out.println("Do you want to deposit money?....say yes or no");
		String s=sc.nextLine();
		if(s.equals("yes") || s.equals("YES") || s.equals("Yes")) {
			System.out.println("Enter the ammount to be deposited");
			double bal1=sc.nextDouble();
			Account ac=new CurrentAcc(id,name,bal1);
			accountDao.createCAcc(ac);
		}
		else {
			CurrentAcc ac=new CurrentAcc(id,name,0.0);
			accountDao.createCAcc(ac);
		}
	}


	@Override
	public Account searchAccount(int id) {
		Account acc=accountDao.searchAccount(id);
		return acc;
	}


	@Override
	public void withdrawS(Account aw, double amt) {
		double minbal=SavingsAcc.getMinbal();
		if(((aw.getBal())-amt)>minbal) {
			double intd=(aw.getBal())-amt;
			aw.setBal(intd);
		}
		else {
			System.out.println("Not sufficient Balance");
		}
		
	}


	@Override
	public void withdrawC(Account aw,double amt) {
		aw.setBal(amt);
		ac.settransc();
	}


	@Override
	public void deposit(Account ad, double amtd) {
		double intmd1=ad.getBal()+amtd;
		ad.setBal(intmd1);
		
	}


	@Override
	public List<Account> displayAll() {
		return accountDao.getAllAccount();
	}


	
}