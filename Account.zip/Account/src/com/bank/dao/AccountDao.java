package com.bank.dao;

import java.util.List;

import com.bank.bean.Account;
import com.bank.bean.CurrentAcc;
import com.bank.bean.SavingsAcc;

public interface AccountDao {

	void createSAcc(Account as );

	void createCAcc(Account ac);

	Account searchAccount(int id);

	List<Account> getAllAccount();

}
