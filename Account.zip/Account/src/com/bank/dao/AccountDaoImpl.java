package com.bank.dao;

import java.util.ArrayList;
import java.util.List;

import com.bank.bean.Account;
import com.bank.bean.CurrentAcc;
import com.bank.bean.SavingsAcc;



public class AccountDaoImpl implements AccountDao{
	static List<Account> plist;
	static {
		plist=new ArrayList<>();
		plist.add(new SavingsAcc(12,"chair",20000,"wer"));
		plist.add(new SavingsAcc(13,"table",30000,"ser"));
	}
	
	
	@Override
	public void createSAcc(Account as) {
		plist.add(as);
		
	}


	@Override
	public void createCAcc(Account ac) {
		plist.add(ac);
		
	}


	@Override
	public Account searchAccount(int id) {
		int pos=plist.indexOf(new Account(id,null,0.0));
		if(pos!=-1) {
			return plist.get(pos);
		}
		return null;
	}


	@Override
	public List<Account> getAllAccount() {
		return plist;
	}

}
