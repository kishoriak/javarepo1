package com.bank.test;

import java.util.List;
import java.util.Scanner;

import com.bank.bean.Account;
import com.bank.service.AccountService;
import com.bank.service.AccountServiceImpl;




public class TestAccountArray {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int choice;
		AccountService acc=new AccountServiceImpl();
		do {
			System.out.println("1.Create Account\n2.Withdraw Amount\n3.Deposit Amount\n4.Display Details\n5.search by id\n6.Exit");
			System.out.println("Enter Your choice:");
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				System.out.println("1.Savings Account\n2.Current Account");
				System.out.println("Enter Your choice:");
				int ch=sc.nextInt();
				if(ch==1) {
					acc.createSAcc();
				}
				else
					acc.createCAcc();
				break;
				case 2:
					System.out.println("Enter 1 to withdraw from savings account and 2 for current account");
					int ch1=sc.nextInt();
					System.out.println("Enter the id");
					int id=sc.nextInt();
					System.out.println("Enter the ammount to be withdrawn");
					double amtw=sc.nextDouble();
					Account aw=acc.searchAccount(id);
					if(ch1==1) {
						acc.withdrawS(aw,amtw);
					}
					else
						acc.withdrawC(aw,amtw);
					break;
				case 3:
					System.out.println("Enter the id");
					int id1=sc.nextInt();
					System.out.println("Enter the ammount to be deposited");
					double amtd=sc.nextDouble();
					Account ad=acc.searchAccount(id1);
					acc.deposit(ad,amtd);
					break;
				case 4:
					List<Account> plist=acc.displayAll();
					for(Account a1:plist) {
						System.out.println(a1);
					}
					break;
				case 5:
					System.out.println("enetr id");
					int id2=sc.nextInt();
					Account p=acc.searchAccount(id2);
					if(p!=null) {
						System.out.println(p);
					}
					else {
						System.out.println("not found");
					}
					break;
				case 6:
					sc.close();
					System.exit(0);
			}
		}while(choice!=5);
	}

}
