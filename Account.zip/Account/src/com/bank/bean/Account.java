package com.bank.bean;

public class Account {
	private int id;
	private String name;
	protected double bal;
	
	public Account() {
	}

	public Account(int id, String name, double bal) {
		this.id = id;
		this.name = name;
		this.bal = bal;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBal() {
		return bal;
	}

	public void setBal(double bal) {
		this.bal = bal;
	}

	@Override
	public String toString() {
		return "Id=" + id + ", name=" + name + ", bal=" + bal;
	}
	
	
	
}
	