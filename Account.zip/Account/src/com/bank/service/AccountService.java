package com.bank.service;

import java.util.List;

import com.bank.bean.Account;

public interface AccountService {

	void createSAcc();

	void createCAcc();

	 Account searchAccount(int id);

	void withdrawS(Account a,double amt);

	void withdrawC(Account a, double amt);

	void deposit(Account ad, double amtd);

	List<Account> displayAll();
	
	

}
