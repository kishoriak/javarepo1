package com.demo.service;

import java.util.ArrayList;
import java.util.List;

import com.demo.bean.TextAndImageNote;
import com.demo.bean.TextNote;

public class NoteStoreImpl implements NoteStore{
	
	static List<TextNote> tn;   //Text Notes List
	static List<TextAndImageNote> tain;   //Text And Image Notes List
	static{
		tn=new ArrayList<>();
		tain =new ArrayList<>();
	}
	
	

	public void storeNotes(String txt, String url) {
		tain.add(new TextAndImageNote(txt,url));
		
	}



	@Override
	public void storeNotes(String txt) {
		tn.add(new TextNote(txt));
		
	}



	@Override
	public List<TextNote> getAllTextNote() {
		return tn;
	}



	


	@Override
	public List<TextAndImageNote> getAllTextAndImageNote() {
		return tain;
	}



	@Override
	public void displayTextNotes() {
		List<TextNote> t =  getAllTextNote();  //t = text list
		t.forEach((p)->{System.out.println(p);});
		
	}



	@Override
	public void displayTextAndImageNotes() {  // t = Text and Image list
		List<TextAndImageNote> t =  getAllTextAndImageNote();
		
		t.forEach((p)->{System.out.println(p);});
		
	}
	
}
