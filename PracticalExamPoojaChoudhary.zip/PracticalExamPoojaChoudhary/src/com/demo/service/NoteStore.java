package com.demo.service;

import java.util.List;

import com.demo.bean.TextAndImageNote;
import com.demo.bean.TextNote;

public interface NoteStore {

	void storeNotes(String txt, String url);

	void storeNotes(String txt);

	List<TextNote> getAllTextNote();

	List<TextAndImageNote> getAllTextAndImageNote();

	void displayTextNotes();

	void displayTextAndImageNotes();

}
