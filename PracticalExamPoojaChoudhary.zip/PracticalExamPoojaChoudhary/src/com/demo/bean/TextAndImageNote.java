package com.demo.bean;

public class TextAndImageNote {
	private String msg;
	private String url;
	
	//Default
	public TextAndImageNote() {
		super();
	}
	
	//Parameterized
	public TextAndImageNote(String msg, String url) {
		super();
		this.msg = msg;
		this.url = url;
	}
	
	//Getter Setter Methods
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	//Printing 
	@Override
	public String toString() {
		return "TextAndImageNote : "+ msg +", \n "+  url;
	}
	
}
