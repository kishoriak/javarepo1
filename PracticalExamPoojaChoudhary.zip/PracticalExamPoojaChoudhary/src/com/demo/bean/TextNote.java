package com.demo.bean;

public class TextNote {
		public String msg;
		
		//Default
		public TextNote() {
			super();
		}
		//Parameterized
		public TextNote(String msg) {
			super();
			this.msg = msg;
		}
		
		// Getter Setter
		public String getMsg() {
			return msg;
		}

		public void setMsg(String msg) {
			this.msg = msg;
		}
		//Printing
		
		@Override
		public String toString() {
			return "TextNote:" + msg ;
		}
		
}
