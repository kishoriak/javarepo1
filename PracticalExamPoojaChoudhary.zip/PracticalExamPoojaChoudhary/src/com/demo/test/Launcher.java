package com.demo.test;

import java.util.List;
import java.util.Scanner;

import com.demo.bean.TextAndImageNote;
import com.demo.bean.TextNote;
import com.demo.service.NoteStore;
import com.demo.service.NoteStoreImpl;

//Main Method
public class Launcher {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int choice=0;
		NoteStore noteStore=new NoteStoreImpl();
		
		do {
			//Taking Choice from the user
			System.out.println("1. Store Notes \n 2. Get Text \n 3. Get Text and Image  \n 4. Display Text \n 6. Display Text And Image \n 6.Exit");
			System.out.println("choice");
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				System.out.println("What do you want to store \n 1. Text Note \n 2. Text And Image Notes");
				int ch=sc.nextInt();
				if(ch==1) {
					System.out.println("Enter the Text ");
					String txt =sc.next();
					noteStore.storeNotes(txt);
				}
				else {
					if(ch ==2) {
						System.out.println("Enter the Text  ");
						String txt =sc.next();
						System.out.println("Enter the Image URL ");
						String url =sc.next();
						noteStore.storeNotes(txt,url);
			
						
					}
				}
				
				break;
			case 2:
				List<TextNote> n = noteStore.getAllTextNote();
				break;
			case 3:
				List<TextAndImageNote> n1 = noteStore.getAllTextAndImageNote();
				break;
			case 4:
				noteStore.displayTextNotes();
				break;
			case 5:
				noteStore.displayTextAndImageNotes();
				break;
			case 6:
				sc.close();
				System.exit(0);
				break;
			}
		}while(choice!=6);

	}

}
