package com.demo.test;

import java.util.List;
import java.util.Scanner;

import com.demo.bean.Note;
import com.demo.bean.TextAndImageNote;
import com.demo.bean.TextNote;
import com.demo.service.NoteService;
import com.demo.service.NoteServiceImpl;

public class Launcher {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int choice=0;
		NoteService noteService=new NoteServiceImpl();
		try {
			do {
			System.out.println("1. add Note\n2.add NoteandImage\n3.Display notes\n4.Display notes and Images\n4.Exit ");
			System.out.println("choice");
			choice=sc.nextInt();
			sc.nextLine();
			switch(choice) {
			case 1:
				//taking input
				System.out.println("enter Note");
				String note=sc.nextLine();
				Note n =new TextNote(note);
				//calling service
				noteService.storeNoteSevice(n);
				break;
			case 2:
				//taking input
				System.out.println("enter Note");
				note=sc.nextLine();
				System.out.println("enter Image Url");
				String url=sc.nextLine();
				Note n1 =new TextAndImageNote(note,url);
				//calling service
				noteService.storeNoteSevice(n1);
				break;
			case 3:
				//calling service
				List<Note> plist=noteService.getAllTextNotesSevice();
				for(Note p1:plist) {
					System.out.println(p1);
				}
				break;
			case 4:
				//calling service
				plist=noteService.getAllTextAndImageNotesSevice();
				for(Note p1:plist) {
					System.out.println(p1);
				}
				break;
			case 5:
				//Exit system
				System.exit(0);
			}
			}while(choice!=5);
		}catch(Exception e) {
			System.out.println("Encountered Error Check the entries");
		}finally {
			sc.close();
			System.exit(0);
		}
		
	}

}
