package com.demo.dao;

import java.util.ArrayList;
import java.util.List;

import com.demo.bean.Note;
import com.demo.bean.TextAndImageNote;
import com.demo.bean.TextNote;

public class NotesDaoImpl implements NotesDao{
	private static List<Note> plist;
	static {
		plist=new ArrayList<>();
	}
	@Override
	public void storeNote(Note n) {
		// TODO Auto-generated method stub
		plist.add(n);
	}
	@Override
	public List<Note> getAllNotesTextNotes() {
		// TODO Auto-generated method stub
		List<Note> tlist=new ArrayList<>();
		for(Note p1:plist) {
			if(p1 instanceof TextNote){
				tlist.add(p1);
			}
		}
		return tlist;
	}
	@Override
	public List<Note> getAllTextAndImageNotes() {
		// TODO Auto-generated method stub
		List<Note> tlist=new ArrayList<>();
		for(Note p1:plist) {
			if(p1 instanceof TextAndImageNote){
				tlist.add(p1);
			}
		}
		return tlist;
	}
	
	
	
	
}
