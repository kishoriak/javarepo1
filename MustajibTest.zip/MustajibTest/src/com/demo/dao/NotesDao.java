package com.demo.dao;

import java.util.List;

import com.demo.bean.Note;

public interface NotesDao {
	
	void storeNote(Note n);
	
	List<Note> getAllNotesTextNotes();
	
	List<Note> getAllTextAndImageNotes();
}
