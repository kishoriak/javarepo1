package com.demo.bean;

public class TextAndImageNote extends Note {
	String image_url;

	public TextAndImageNote(String image_url,String text) {
		super(text);
		this.image_url = image_url;
	}

	public TextAndImageNote() {
		super();
	}

	public String getImage_url() {
		return image_url;
	}

	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}

	@Override
	public String toString() {
		return "TextAndImageNote [image_url=" + image_url + ", text=" + text + "]";
	}
	
	
}
