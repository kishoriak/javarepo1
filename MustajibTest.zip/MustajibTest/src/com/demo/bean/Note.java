package com.demo.bean;

abstract public class Note {
	String text;

	public Note() {
		super();
	}

	public Note(String text) {
		super();
		this.text = text;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
}
