package com.demo.bean;

public class TextNote extends Note {
	public TextNote() {
		super();
	}
	
	public TextNote(String text) {
		super(text);
	}
	
	@Override
	public String toString() {
		return "TextNote [text=" + text + "]";
	}
	
	
}
