package com.demo.service;

import java.util.List;

import com.demo.bean.Note;
import com.demo.dao.NotesDao;
import com.demo.dao.NotesDaoImpl;

public class NoteServiceImpl implements NoteService {
	private NotesDao noteDao=new NotesDaoImpl();
	@Override
	public List<Note> getAllTextAndImageNotesSevice() {
		// TODO Auto-generated method stub
		return  noteDao.getAllTextAndImageNotes();
	}

	@Override
	public List<Note> getAllTextNotesSevice() {
		// TODO Auto-generated method stub
		return noteDao.getAllNotesTextNotes();
	}

	@Override
	public void storeNoteSevice(Note n) {
		// TODO Auto-generated method stub
		noteDao.storeNote(n);
	}

}
