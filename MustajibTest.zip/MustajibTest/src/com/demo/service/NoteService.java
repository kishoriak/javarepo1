package com.demo.service;


import java.util.List;

import com.demo.bean.Note;

public interface NoteService {
	List<Note> getAllTextAndImageNotesSevice();
	
	List<Note> getAllTextNotesSevice();
	
	void storeNoteSevice(Note n); 
}
